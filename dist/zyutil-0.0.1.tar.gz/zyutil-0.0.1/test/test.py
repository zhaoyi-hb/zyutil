from code_metric import test
from file_util import json_util_test
test()
json_util_test()