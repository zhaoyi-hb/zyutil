# introduction
personnal utils