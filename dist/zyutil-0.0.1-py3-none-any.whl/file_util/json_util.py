def json_util_test():
    print("json util test ok ")